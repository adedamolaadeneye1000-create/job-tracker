// Your Supabase connection details.
// In Supabase, open your project and click "Connect" at the top of the page.
// Copy the Project URL and the publishable key (it starts with sb_publishable_) into the quotes below.
//
// The publishable key is designed to be public: Row Level Security in supabase/schema.sql
// makes sure only you can read or change your applications.
// NEVER paste the secret key (sb_secret_...) or the service_role key here.

window.APP_CONFIG = {
  supabaseUrl: "PASTE_YOUR_PROJECT_URL_HERE",
  supabaseKey: "PASTE_YOUR_PUBLISHABLE_KEY_HERE"
};
